#ifndef MINDSPORE_MODELS_UTILS_INFER_H_
#define MINDSPORE_MODELS_UTILS_INFER_H_

#include <string>
#include <memory>
#include "common_inc/utils.h"
#include "include/api/model.h"
#include "include/api/context.h"
#include "include/api/types.h"
#include "include/api/serialization.h"
#include "include/dataset/execute.h"
#include "include/dataset/transforms.h"
#ifdef ENABLE_LITE
#include "include/dataset/vision_lite.h"
#else
#include "include/dataset/vision.h"
#endif
#include "include/dataset/vision_ascend.h"

using mindspore::Context;
using mindspore::Model;
using mindspore::MSTensor;
using mindspore::Serialization;
using mindspore::Status;
using mindspore::GraphCell;

using mindspore::dataset::Execute;
using mindspore::dataset::InterpolationMode;
using mindspore::dataset::TensorTransform;
using mindspore::dataset::transforms::TypeCast;
using namespace mindspore::dataset::vision;

bool LoadModel(const std::string &mindir_path, const std::shared_ptr<mindspore::Context> &context, Model *model);

bool LoadModel(const std::string &mindir_path, const std::string &device_type, uint32_t device_id,
               const std::shared_ptr<mindspore::AscendDeviceInfo> &ascend_device_info, Model *model);

bool LoadModel(const std::string &mindir_path, const std::string &device_type, uint32_t device_id, Model *model);

#endif  // MINDSPORE_MODELS_UTILS_INFER_H_
