# 一、课程简介
课程名称：CUDA编程基础入门系列（持续更新）    
作者：权双      
课程视频链接：https://www.bilibili.com/video/BV1sM4y1x7of/    
# 二、文档说明
1、该仓库上传了课程使用的代码，因为GPU硬件的差异，因此未上传编译好的可执行文件；       
2、课件下载链接：https://pan.baidu.com/s/1MyM1_j0EZcc69pG69-C9ww 提取码：1234     

# 三、视频课程目录

| 视频                                                         |  博客  |
| :----------------------------------------------------------- | :----: |
| [1.1CUDA简介](https://www.bilibili.com/video/BV1sM4y1x7of/?spm_id_from=333.1007.top_right_bar_window_history.content.click&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [1.2CUDA下载安装及测试](https://www.bilibili.com/video/BV1sM4y1x7of?p=2&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [1.3nvidia-smi工具使用](https://www.bilibili.com/video/BV1sM4y1x7of?p=3&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [2.1从C++编程到CUDA编程](https://www.bilibili.com/video/BV1sM4y1x7of?p=4&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [2.2核函数](https://www.bilibili.com/video/BV1sM4y1x7of?p=5&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [2.3线程模型](https://www.bilibili.com/video/BV1sM4y1x7of?p=6&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [2.4线程全局索引计算方式](https://www.bilibili.com/video/BV1sM4y1x7of?p=7&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [2.5nvcc编译流程与GPU计算能力](https://www.bilibili.com/video/BV1sM4y1x7of?p=8&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [2.6CUDA程序兼容性问题](https://www.bilibili.com/video/BV1sM4y1x7of?p=9&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [3.1CUDA矩阵加法运算程序](https://www.bilibili.com/video/BV1sM4y1x7of?p=10&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [3.2CUDA错误检查](https://www.bilibili.com/video/BV1sM4y1x7of?p=11&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [3.3CUDA记时](https://www.bilibili.com/video/BV1sM4y1x7of?p=12&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [3.4运行时GPU信息查询](https://www.bilibili.com/video/BV1sM4y1x7of/?p=13&spm_id_from=333.1007.top_right_bar_window_history.content.click&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [3.5组织线程模型](https://www.bilibili.com/video/BV1sM4y1x7of?p=15&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.1GPU硬件资源](https://www.bilibili.com/video/BV1sM4y1x7of?p=16&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.2CUDA内存模型概述](https://www.bilibili.com/video/BV1sM4y1x7of?p=17&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.3寄存器和本地内存](https://www.bilibili.com/video/BV1sM4y1x7of?p=18&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.4全局内存](https://www.bilibili.com/video/BV1sM4y1x7of?p=19&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.5共享内存](https://www.bilibili.com/video/BV1sM4y1x7of?p=20&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.6常量内存](https://www.bilibili.com/video/BV1sM4y1x7of?p=21&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.8计算资源分配](https://www.bilibili.com/video/BV1sM4y1x7of?p=23&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.9延迟隐藏](https://www.bilibili.com/video/BV1sM4y1x7of?p=24&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |
| [4.10避免线程束分化](https://www.bilibili.com/video/BV1sM4y1x7of?p=25&vd_source=51a76af86bf4fcc9da32a69c092094ea) | 待更新 |

