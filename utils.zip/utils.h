#ifndef MINDSPORE_MODELS_COMMON_UTILS_H_
#define MINDSPORE_MODELS_COMMON_UTILS_H_

#include <string>
#include <vector>
#include "include/api/types.h"

bool GetDirFiles(const std::string &dir_name, std::vector<std::string> *sub_dirs, std::vector<std::string> *sub_files,
                 const std::vector<std::string> &extensions = {});
std::vector<std::string> GetAllFiles(const std::string &dirName, const std::vector<std::string> &extensions = {});
std::vector<std::vector<std::string>> GetAllInputData(const std::string &dir_name,
                                                      const std::vector<std::string> &extensions = {});
std::string RealPath(const std::string &path);
mindspore::MSTensor ReadFileToTensor(const std::string &file);
std::vector<std::string> GetImagesById(const std::string &idFile, const std::string &dirName);
int WriteResult(const std::string &imageFile, const std::vector<mindspore::MSTensor> &outputs,
                const std::string &homePath = "./result_Files");
int WriteResultNoIndex(const std::string &imageFile, const std::vector<mindspore::MSTensor> &outputs,
                       const std::string &homePath = "./result_Files");
DIR *OpenDir(const std::string &dirName);

#endif
