#ifndef MINDSPORE_MODELS_UTILS_FLAG_PARSER_H_
#define MINDSPORE_MODELS_UTILS_FLAG_PARSER_H_

#include <map>
#include <vector>
#include <utility>
#include <string>

// Declare flag functions
bool ParseCommandLineFlags(int argc, char **argv);
bool ParseCommandLineFlags(int *argc, char ***argv);

// Declare flag macros
#define DEFINE_string(name, default_val, desc) extern std::string FLAGS_##name;
#define DEFINE_int32(name, default_val, desc) extern int32_t FLAGS_##name;
#define DEFINE_bool(name, default_val, desc) extern bool FLAGS_##name;

// Define the _FlagInfo structure
enum _FlagType {
  _FlagTypeString = 0,
  _FlagTypeInt32 = 1,
  _FlagTypeBool = 16,
};

struct _FlagInfo {
  std::string name;
  std::string desc;
  _FlagType type = _FlagTypeString;

  std::string *str_val = nullptr;
  int32_t *int32_val = nullptr;
  bool *bool_val = nullptr;
};

// Define the _FlagsStorage class
class _FlagsStorage {
 public:
  static _FlagsStorage &Instance();
  bool Reg(const _FlagInfo &info);
  _FlagInfo *GetFlag(const std::string &name);
  std::vector<_FlagInfo> flags;

 private:
  _FlagsStorage() = default;
  _FlagsStorage(const _FlagsStorage &) = delete;
  _FlagsStorage &operator=(const _FlagsStorage &) = delete;
};

// Define the _FlagsReg class
class _FlagsReg {
 public:
  _FlagsReg(const std::string &name, const std::string &desc, std::string *var);
  _FlagsReg(const std::string &name, const std::string &desc, int32_t *var);
  _FlagsReg(const std::string &name, const std::string &desc, bool *var);
};

// Define utility functions
inline void Trim(std::string *input);
std::string GetFileName(const std::string &path);
template <typename T> bool GenericParseValue(const std::string &value, T *ret_val);

#endif  // MINDSPORE_MODELS_UTILS_FLAG_PARSER_H_
